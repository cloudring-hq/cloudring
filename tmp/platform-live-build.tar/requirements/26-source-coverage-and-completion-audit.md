# Source Coverage And Completion Audit

Этот документ фиксирует покрытие source intake для legacy source bundle и
проверяет текущую папку `requirements` против исходной цели CloudRING.

Он нужен, чтобы будущие агенты не путали сильный product synthesis с полным
line-by-line audit. Если анализ был sampled, history-focused or targeted, это
должно быть видно. Если когда-то будет заявлено "источник разобран полностью",
это заявление должно иметь coverage evidence.

## Requirements

| ID | Требование | Почему | Acceptance |
|---|---|---|---|
| CR-SRCOV-001 | Каждый source intake должен иметь coverage manifest. | Без manifest частичный анализ создает ложную уверенность. | Manifest records source class, file counts, exclusions, method, coverage status and limitations. |
| CR-SRCOV-002 | Coverage manifest must distinguish indexed, significant and excluded files. | Vendor/generated noise and product source require different treatment. | Report separates total indexed files, analyzed significant files and excluded dependency/generated/history stores. |
| CR-SRCOV-003 | Coverage claim must state whether analysis is complete, targeted, sampled or history-focused. | Agents must not overclaim evidence. | Each source class has coverage mode and cannot be called complete without explicit proof. |
| CR-SRCOV-004 | Git history intake must record refs, tags, commit-count class and limitations. | "Every decision in history" requires stronger evidence than current tree reading. | History manifest states repos analyzed, empty repos, tag type/discipline, debug/pre-release and duplicate-tag treatment, current branch limits and whether deleted paths/all refs were included. |
| CR-SRCOV-005 | Source safety scan must be part of coverage. | Legacy sources often contain private context and secret-class material. | Intake records anonymization checks, secret-class handling and no raw value transfer. |
| CR-SRCOV-006 | Coverage must distinguish product signals from implementation details. | Requirements should preserve why, not freeze old technology. | Each source class maps to product signals and requirement ranges, not copied code/config. |
| CR-SRCOV-007 | Exclusions must be named by category, not silently ignored. | Future agents need to know what was intentionally skipped. | Vendor, generated, empty sandbox, third-party reference and binary/static assets have explicit treatment. |
| CR-SRCOV-008 | Completion audit must preserve original objective scope. | The goal is larger than current progress. | Audit lists objective requirements, current evidence, status and next evidence needed without redefining success. |
| CR-SRCOV-009 | Completion cannot be claimed from passing validation scripts alone. | ID/link/security checks do not prove semantic completeness. | Completion audit separates structural validation from source coverage and product sufficiency. |
| CR-SRCOV-010 | Source-derived requirements must remain reimplementation-oriented. | If original sources disappear, product meaning should survive. | Requirement output states what/why/evidence/stop conditions and avoids exact source text. |
| CR-SRCOV-011 | Each future exhaustive pass must have a bounded source slice. | "Analyze everything" is too broad for one agent action. | Workstream slice names source class, files/refs, expected signals, exclusions and validation output. |
| CR-SRCOV-012 | Coverage manifest must be updated after source bundle changes. | Stale source counts are misleading. | Manifest includes date/iteration and requires refresh when file inventory or refs change. |
| CR-SRCOV-013 | Pilot/company anonymity must be verified independently from source coverage. | A complete analysis can still be unsafe. | Review commands scan requirements for forbidden private names, paths, IPs, URLs and secret-like values. |
| CR-SRCOV-014 | Source analysis limitations must be first-class requirements input. | Limitations are not failure; hiding them is failure. | Limitations create follow-up workstreams or accepted exclusions with owner/reason. |
| CR-SRCOV-015 | Coverage evidence must be agent-readable. | Future agents must continue without human memory. | Manifest uses tables, stable IDs, requirement refs and stop conditions. |
| CR-SRCOV-016 | Source-intake agents must report method and non-claims. | Agent output should be safe and epistemically honest. | Agent result states what was scanned, what was sampled, what was excluded and what must not be inferred. |
| CR-SRCOV-017 | Full-history claim requires all-refs/deleted-path treatment. | Current branch alone can miss important decisions. | History-ready status requires all refs/tags, deleted paths, file-category churn and safe redacted theme extraction. |
| CR-SRCOV-018 | Coverage manifest must protect against copyright drift. | Repeated paraphrase work can accidentally copy source shape. | Review checks that requirements contain product abstractions, not long source snippets, exact configs or private operational commands. |

## Current Coverage Manifest

Snapshot date: 2026-06-22.

| Metric | Current Value | Meaning |
|---|---:|---|
| Indexed files in legacy source bundle | 3577 | Raw filesystem count from source inventory. |
| Significant files after excluding history/dependency/generated noise | 418 | Candidate files for product-signal extraction. |
| High-signal docs/config/schema/spec files | 173 | Files likely to describe product contracts, operations, schemas or decisions. |
| Git repositories found | 6 | Local history stores available for history-focused analysis. |
| Empty or non-useful repositories | 1 | No product requirement extracted. |

## Significant Inventory Classification Closure

This section proves classification coverage for the 418 significant files. It
does not prove line-by-line review, runtime behavior, vulnerability absence or
complete historical decision recovery.

| Source Class | Significant Files | Classifier Boundary | Classification Status | Coverage Status |
|---|---:|---|---|---|
| Legacy platform prototype | 241 | Platform docs, local runtime, service factory, command, manifest, task, plugin and showcase materials. | Classification closed | Product-signal synthesized in `SRC-PASS-001`; lifecycle command surface deepened in `SRC-PASS-011`; documentation/ADR/developer-guidance memory deepened in `SRC-PASS-014`; service dependency/deployment model deepened in `SRC-PASS-016`; line-by-line and history coverage not fully performed for the selected slices. |
| Encrypted secrets reference | 63 | Reference controller/schema/security materials used only for secret-boundary product lessons. | Classification closed | Targeted reference analysis; secret runtime readiness evidence deepened in `SRC-PASS-015`; no live runtime, decrypted value, vulnerability, dependency or security-completeness claim. |
| Usage metrics gateway prototype | 55 | Usage API, access, billing, queue, observability and release/test materials. | Classification closed | Product-signal and all-refs history-theme reviewed in `SRC-PASS-002`; billing runtime, release/history and settlement-trust evidence deepened in `SRC-PASS-012`; line-by-line and downstream settlement audit not performed. |
| UI validation prototype | 25 | Validation rule, form/error, fixture and small UI validation history materials. | Classification closed | Product-signal and all-refs history-theme reviewed in `SRC-PASS-004`; UI extension runtime certification evidence deepened in `SRC-PASS-018`; runtime/browser certification not executed. |
| VM/image factory prototype | 20 | Image build, hardening, bootstrap, cleanup, diagnostics and release-history materials. | Classification closed | Product-signal and all-refs history-theme reviewed in `SRC-PASS-003`; base OS image factory readiness deepened in `SRC-PASS-017`; image build/boot not executed. |
| UI composition prototype | 13 | UI embedding, bootstrap/provider, typed context and extension boundary materials. | Classification closed | Product-signal and all-refs history-theme reviewed in `SRC-PASS-004`; UI extension runtime certification evidence deepened in `SRC-PASS-018`; marketplace publication not executed. |
| Stateful operations history | 1 current-branch file plus history refs | Stateful HA, backup, DNS/service-discovery, audit, access and source-safety history materials. | Classification closed | All available local and remote-tracking refs history-theme reviewed in `SRC-PASS-005`; restore/failover reusable evidence package deepened in `SRC-PASS-013`; live restore/infrastructure audit not performed. |

Classification totals: significant files `418`; source-class unknown `0`;
source-class overlap `0` after priority classification. These numbers are
inventory evidence only and must not be used as a full source-completion claim.

## Common-Noise Exclusion Manifest

| Exclusion Category | Files | Reason | Safety Treatment | Future Treatment |
|---|---:|---|---|---|
| Dependency/vendor material | 3158 | Third-party or vendored dependency content is not CloudRING product memory. | Not transferred into requirements; product signals only if future source explicitly asks to analyze dependency policy. | Keep excluded unless a supply-chain/source-license pass is requested. |
| Generated/build output | 1 | Derived output is not source-of-truth. | Not transferred into requirements; generated artifact lessons are captured as product requirements elsewhere. | Recheck only if generated output itself becomes publication evidence. |
| Other excluded categories | 0 | No additional common-noise files in current inventory command. | Not applicable. | Not applicable. |

Exclusion totals: raw indexed files `3577`; excluded common-noise files `3159`;
significant files `418`.

## Source Class Coverage

| Source Class | Significant Files | Coverage Mode | Product Signals Extracted | Requirement Ranges |
|---|---:|---|---|---|
| Legacy platform prototype | 241 | Completed targeted current-tree pass in `SRC-PASS-001`; completed deeper current-tree lifecycle command surface pass in `SRC-PASS-011`; completed documentation/ADR/developer-guidance decision-memory pass in `SRC-PASS-014`; completed service dependency/deployment model pass in `SRC-PASS-016`; not full line-by-line audit and no history claim for these slices | Service manifest, local runtime, lifecycle command contracts, create/scaffold, validation, debug/start split, task library, plugin boundary, docs preview, environment export, generated artifacts, preflight, cleanup, support-ready evidence, documentation as product control plane, ADR/no-ADR rationale, feedback triage, docs/source-safety, freshness, reusable decision-memory chain, effective service model, dependency graph, component ownership, generated artifact inventory, env handoff, conflict preflight, data roles, dependency portability and source-safe non-claims. | `CR-OCSCONTRACT-001..046`, `CR-SERVICEFACTORY-001..050`, `CR-DOMAIN-011..020`, `CR-OPS-036..037`, `CR-LIFECMD-001..032`, `CR-DOCMEM-001..032`, `CR-SVCDEPLOY-001..032` |
| Encrypted secrets reference | 63 | Completed targeted reference analysis; completed current-tree secret runtime readiness pass in `SRC-PASS-015`; no local git history, live runtime, decrypted value, vulnerability or dependency audit claim | Secret references, encrypted-data classification, scope binding, scope weakening approval, key custody, public certificate distribution/freshness, key identity, observed generation, sync conditions, CRD/API schema strictness, install/delete retention, RBAC, health/metrics redaction, rotation/rebinding, degraded/fail-closed behavior, supply-chain trust and source-safe non-claims. | `CR-SECSUPPLY-001..038`, `CR-CAPEVID-015`, `CR-CAPEVID-022`, `CR-CAPEVID-026`, `CR-SECRETRUN-001..032` |
| Usage metrics gateway prototype | 55 | Completed targeted current-tree and all-refs history/theme pass in `SRC-PASS-002`; completed deeper billing runtime evidence and history pass in `SRC-PASS-012`; not full line-by-line or downstream settlement audit | Usage resources, scoped access, idempotency, period policy, queue/backpressure, decision ledger, async receipt/status, event identity, batch semantics, access freshness, shutdown drain, replay/quarantine, release/history evidence, generated artifact safety and settlement freeze. | `CR-BILL-001..036`, `CR-FED-019..036`, `CR-CAPEVID-021`, `CR-BILLRUN-001..032` |
| UI validation prototype | 25 | Completed targeted current-tree and all-refs history/theme pass in `SRC-PASS-004`; completed bounded validation-runtime certification pass in `SRC-PASS-018`; not full line-by-line, live browser, accessibility, localization or performance audit | Validation rule identity, timing/state model, field-level error lifecycle, dependent rules, stable error identity gap, human/machine error boundary, UI/API/CLI/agent parity, negative fixtures, bounded runtime/size/regex budget, browser/runtime evidence gap and accessibility/localization evidence gaps. | `CR-DX-027..029`, `CR-OCSCONTRACT-018`, `CR-OCSCONTRACT-038..046`, `CR-SECSUPPLY-034..036`, `CR-UICERT-001..032`, `CR-CONF-039`, `CR-CAPEVID-029` |
| VM/image factory prototype | 20 | Completed targeted current-tree and all-refs history/theme pass in `SRC-PASS-003`; completed bounded current-tree plus local history-shape base OS image readiness pass in `SRC-PASS-017`; not full line-by-line, live build/boot, vulnerability or deleted-path audit | Image provenance, hardening, cleanup, diagnostics, release evidence, freshness, publication handoff, source-safety risk classes, base image identity, build input classification, unattended install, provisioning roles, guest readiness, cleanup/sealing, immutable artifact identity, first-boot evidence gap, promotion lifecycle and source-safe non-claims. | `CR-SECSUPPLY-030..037`, `CR-MKT-029..036`, `CR-CATALOG-021..028`, `CR-BASEIMG-001..032`, `CR-CONF-038`, `CR-CAPEVID-028` |
| UI composition prototype | 13 | Completed targeted current-tree and all-refs history/theme pass in `SRC-PASS-004`; completed bounded embedded UI publication-certification pass in `SRC-PASS-018`; not full runtime/browser or marketplace publication audit | UI embedding, standalone vs embedded mode, typed scoped context, host authority boundary, lifecycle mount/update/unmount/failure cleanup, support owner, trust manifest, lifecycle/theming boundary, accessibility/compatibility gaps, publication proof gap and release evidence gap. | `CR-DX-025..026`, `CR-OCSCONTRACT-017`, `CR-OCSCONTRACT-036`, `CR-SECSUPPLY-016`, `CR-SECSUPPLY-032`, `CR-MKT-037..040`, `CR-UICERT-001..032`, `CR-CONF-039`, `CR-CAPEVID-029` |
| Stateful DNS/database operations history | 1 current-branch file plus history refs | Completed all available local and remote-tracking refs history/product-signal and source-safety pass in `SRC-PASS-005`; completed deeper restore/failover readiness evidence pass in `SRC-PASS-013`; not full line-by-line or live restore/failover audit | HA topology, node classes, failover/write endpoint semantics, RPO/RTO, backup/restore evidence gap, audit bundles, runbook dependency churn, access roles, source-safety risk classes, reusable recovery evidence template, restore/PITR/failover blockers, history/current-tree non-claims and provider recovery scenario coverage. | `CR-OPS-021..046`, `CR-OBSOPS-001..036`, `CR-INFPROFILE-005..006`, `CR-INFPROFILE-031`, `CR-STAGE7-038..039`, `CR-STATEFULRUN-001..032` |

## Git History Coverage

| History Class | Coverage Mode | Extracted Signal | Limitation |
|---|---|---|---|
| Usage gateway history | All-refs theme scan plus targeted comparison | Release tags, validation fixes, logging/tracing, queues, config/secrets, tests, generated docs and deleted-path categories. | Not a line-by-line vulnerability, secret or deleted-source audit. |
| Image factory history | All-refs theme scan plus targeted comparison; `SRC-PASS-017` added current-tree plus local history-shape review for base image readiness | CI, image hardening, dependency churn, diagnostics, deleted bootstrap/readiness paths, boot/provisioning reliability themes and zero-tag release gap. | Not a line-by-line vulnerability, secret or deleted-source audit; no live image build/boot claim. |
| UI validation history | All-refs theme scan plus targeted comparison; 9 commits, 0 tags, 11 deleted paths, 0 dirty entries; `SRC-PASS-018` added current-tree plus local history-shape certification review | Validation library evolution, rule identity/timing signals, phased/field validation, limited fixture footprint, no real-browser/accessibility/localization evidence and no release evidence. | Small prototype history; not a full vulnerability/secret audit and requires browser/parity/bounded-runtime fixture evidence before readiness. |
| UI composition history | All-refs theme scan plus targeted comparison; 32 commits, 0 tags, 4 deleted paths, 0 dirty entries; `SRC-PASS-018` added current-tree plus local history-shape certification review | Template/dependency churn, standalone/embed split, provider/context refactor, extension boundary, no lifecycle/publication/accessibility fixture evidence and no release evidence. | Prototype signal only, not full marketplace UI spec, runtime certification or publication readiness. |
| Stateful operations history | All available local and remote-tracking refs history/product-signal and source-safety scan; 29 commits, 0 tags, 91 ever-touched paths, 90 no-longer-tracked historical paths, 5 deleted paths, 0 dirty entries; `SRC-PASS-013` added current-tree plus history cross-check for recovery proof shape | HA/backup/audit/runbook, role lifecycle, evidence-bundle, backup migration, repeated audit/backup/HA loops, source-safety and reusable recovery evidence signals. | Default branch has minimal current files; not a live infrastructure, vulnerability, secret-history, live restore/PITR or failover audit. |
| Empty sandbox history | Inventory only | No useful product signal. | No requirements extracted. |

## Current Completion Audit Against Objective

| Objective Requirement | Current Evidence | Status | Next Evidence Needed |
|---|---|---|---|
| `requirements` folder exists and is extensible | 182 markdown files, README, capabilities, stages, ADR, conformance, templates, examples, scenarios, lifecycle command evidence, service dependency/deployment evidence, billing runtime evidence, stateful recovery evidence, documentation decision-memory evidence, secret runtime readiness evidence, base OS image factory evidence, UI extension runtime certification evidence and traceability. | Strong progress | Continue source intake manifest discipline for each new source. |
| Requirements are Russian/product/AI-agent readable | Files use what/why/acceptance/evidence/stop conditions in Russian with technical terms where useful. | Strong progress | Add more scenario examples as future sources arrive. |
| Source experience is preserved without copying source | Traceability map and capability contracts paraphrase product lessons. | Strong progress | Add exhaustive source-slice passes for remaining high-signal files. |
| No pilot company/private context in requirements | Private/forbidden scans pass for the publishable `requirements/` corpus. Non-requirements workspace files are source/control notes until separately scanned. | Strong progress | Keep scan gate mandatory after every edit and before exporting any artifact outside `requirements/`. |
| Every file and every git decision in legacy bundle analyzed | Current work used inventory, targeted reads, multiple agent passes and history-focused scans. | Not yet fully proven | Need bounded exhaustive passes by source class with coverage reports and all-refs/deleted-path checks. |
| Platform can be reimplemented without source | Architecture, stages, capability contracts, domain model, OCS information model, lifecycle command surface, service dependency/deployment evidence, billing runtime evidence, stateful recovery evidence, documentation decision-memory evidence, secret runtime readiness evidence, base OS image factory evidence, UI extension runtime certification evidence, templates, synthetic examples, scenario fixtures and product design quality evidence are now broad and detailed. | Substantial but incomplete | Need more domain-specific examples, implementation-backed evidence and deeper source-slice audits in later passes. |
| Cloud-of-clouds end-to-end provider vision captured | `CR-END2END`, stages, federation, marketplace, billing, trust, portability and agent ops docs. | Strong progress | Continue refining global governance, legal/jurisdiction and provider economics with future sources. |
| Self-service for user/admin/provider/ISV/agent | Self-service, experience standard, marketplace journeys, agent ops contracts, product design quality review, expanded role scenario fixtures and role coverage matrix. | Strong progress | Add more domain-specific scenario variants as future sources arrive. |
| Finished product at each stage | Stage docs and readiness profiles exist for stages 0-7. | Strong progress | Add more acceptance scenarios and evidence templates per stage. |
| Does not freeze current technologies | Requirements emphasize replaceable profiles, adapters and contracts. | Strong progress | Continue checking new requirements for technology lock-in. |
| Supports future innovation | Extension, plugin, service connector, federation and Stage 7 learning contracts. | Strong progress | Add compatibility/fork governance examples in future iteration. |
| Simple and beautiful product standard | Experience standard, product design quality requirements, review template, synthetic example and stage-depth scenarios make simplicity a readiness artifact. | Strong progress | Add implementation-backed UX evidence when real UI/API surfaces exist. |

## Required Next Exhaustive Passes

| Pass | Scope | Expected Output |
|---|---|---|
| SRC-PASS-001 | Legacy platform prototype high-signal docs, configs and command surfaces. | Completed targeted pass in [source-passes/001-legacy-platform-prototype.md](source-passes/001-legacy-platform-prototype.md): source-safe slice coverage, manifest/command/task/plugin/generator findings and traceability updates. |
| SRC-PASS-002 | Usage gateway current tree and all history refs. | Completed targeted pass in [source-passes/002-usage-gateway.md](source-passes/002-usage-gateway.md): usage/billing conformance fixtures, negative scenarios, release evidence and source coverage update. |
| SRC-PASS-003 | Image/template factory current tree and history. | Completed targeted pass in [source-passes/003-image-template-factory.md](source-passes/003-image-template-factory.md): artifact publication, hardening, cleanup, freshness and support diagnostics requirements. |
| SRC-PASS-004 | UI validation and UI composition prototypes. | Completed targeted pass in [source-passes/004-ui-validation-composition.md](source-passes/004-ui-validation-composition.md): UI embed, validation parity, support owner, extension trust, release evidence and source-safety gaps. |
| SRC-PASS-005 | Stateful operations history refs. | Completed in [source-passes/005-stateful-operations-history.md](source-passes/005-stateful-operations-history.md): HA topology, backup/restore, audit bundle, role lifecycle, reproducible runbook and source-safety requirements. |
| SRC-PASS-006 | Cross-document requirements consistency. | Completed in [source-passes/006-cross-document-consistency.md](source-passes/006-cross-document-consistency.md): architecture vocabulary, ADR candidates, conformance/evidence gaps, source-safety scope, traceability refresh and validation discipline. |
| SRC-PASS-007 | Remaining high-signal source inventory reconciliation and scenario/evidence template closure. | Completed in [source-passes/007-source-inventory-and-evidence-templates.md](source-passes/007-source-inventory-and-evidence-templates.md): significant inventory classification closure, common-noise exclusion manifest, reusable templates and starter role scenario fixtures without full source-completion claim. |
| SRC-PASS-008 | Scenario corpus expansion and filled OCS/conformance examples. | Completed in [source-passes/008-synthetic-examples-and-scenario-expansion.md](source-passes/008-synthetic-examples-and-scenario-expansion.md): filled synthetic OCS/conformance/evidence/profile-change/source-coverage examples and expanded role fixtures without source-history completion claim. |
| SRC-PASS-009 | Product-design quality and scenario depth pass. | Completed in [source-passes/009-product-design-quality-and-scenario-depth.md](source-passes/009-product-design-quality-and-scenario-depth.md): design quality contract, review template/example, metrics, conformance gate, WS-022 and deeper stage scenarios for provider economics, jurisdiction overlays and negative paths. |
| SRC-PASS-010 | OCS information model and schema governance pass. | Completed in [source-passes/010-ocs-information-model-and-schema-governance.md](source-passes/010-ocs-information-model-and-schema-governance.md): semantic OCS model, canonical core field catalog, extension lifecycle, versioned conformance suite, schema governance record, template/example and stage scenarios without choosing final serialization or claiming full source completion. |
| SRC-PASS-011 | Platform lifecycle command surface current-tree slice. | Completed in [source-passes/011-platform-lifecycle-command-surface.md](source-passes/011-platform-lifecycle-command-surface.md): lifecycle command contracts, preflight, risk, structured result, cleanup, task/plugin boundaries, generated artifact provenance and support-ready evidence without source-history claim. |
| SRC-PASS-012 | Usage gateway billing runtime evidence and history. | Completed in [source-passes/012-billing-runtime-evidence-and-history.md](source-passes/012-billing-runtime-evidence-and-history.md): receipt/status, event identity, idempotency conflict, batch semantics, durable/volatile intake, backpressure, shutdown drain, replay/quarantine, access freshness, generated docs/config gates, release/history evidence and settlement freeze without full line-by-line or downstream settlement claim. |
| SRC-PASS-013 | Stateful restore/failover readiness evidence and history. | Completed in [source-passes/013-stateful-restore-failover-readiness.md](source-passes/013-stateful-restore-failover-readiness.md): reusable stateful evidence bundle, topology, backup/archive, restore/PITR, failover, endpoint ownership, audit findings, access roles, source/history coverage, scenarios and conformance gates without live restore/failover or full line-by-line claim. |
| SRC-PASS-014 | Platform documentation, ADR and developer-guidance decision memory. | Completed in [source-passes/014-documentation-decision-memory.md](source-passes/014-documentation-decision-memory.md): docs-as-product-control-plane, onboarding/reference/lifecycle docs, service docs package, command/task/plugin documentation evidence, ADR/no-ADR rationale, feedback triage, source-safety, template/example/scenario and conformance gate without raw docs copying, runtime verification or full history claim. |
| SRC-PASS-015 | Encrypted secrets reference secret runtime readiness. | Completed in [source-passes/015-secret-runtime-readiness.md](source-passes/015-secret-runtime-readiness.md): encrypted declaration boundaries, scope binding, key custody, public certificate freshness, observed generation/conditions, install/delete retention, RBAC, health/metrics, rotation/degraded behavior, source-safety, template/example/scenario and conformance gate without live runtime, decrypted value, vulnerability, dependency or local git history claim. |
| SRC-PASS-016 | Legacy platform service dependency/deployment model. | Completed in [source-passes/016-service-dependency-deployment-model.md](source-passes/016-service-dependency-deployment-model.md): effective service model, profile resolution, dependency graph, component ownership, generated artifact inventory, env handoff, conflict preflight, task/data roles, portability, template/example/scenario and conformance gate without runtime execution, full line-by-line, secret, vulnerability or history claim. |
| SRC-PASS-017 | Base OS image factory readiness. | Completed in [source-passes/017-base-os-image-factory-readiness.md](source-passes/017-base-os-image-factory-readiness.md): base image identity, build input classification, unattended install, provisioning roles, guest readiness, cleanup/sealing, immutable artifact identity, first-boot evidence gap, promotion lifecycle, template/example/scenario and conformance gate without live build/boot, vulnerability, compliance, deleted-path or full history claim. |
| SRC-PASS-018 | UI extension runtime certification. | Completed in [source-passes/018-ui-extension-runtime-certification.md](source-passes/018-ui-extension-runtime-certification.md): validation phase semantics, field error lifecycle, dependent rules, stable error identity gap, UI/API/CLI/Agent parity, browser/runtime gap, accessibility/localization gap, host authority, scoped context, lifecycle cleanup, artifact publication evidence, template/example/scenario and conformance gate without live browser execution, accessibility certification, marketplace publication, vulnerability, compliance or full history claim. |

## Stop Conditions

Agent обязан остановиться и запросить owner/ADR/review, если:

- output claims full source coverage without coverage manifest;
- source-derived requirement contains private name, URL, IP, local path, secret
  value or exact source snippet;
- source class is excluded without category, reason and future treatment;
- history analysis claims "every decision" without all-refs/deleted-path method;
- completion is claimed from ID/link scans without semantic source coverage;
- new source signal changes product promise without ADR or conflict note.

## Non-Goals

- Не хранить raw source inventory with private paths.
- Не копировать commit subjects, code, configs or internal docs.
- Не считать this manifest proof of full line-by-line audit.
- Не превращать source coverage в implementation task list.
