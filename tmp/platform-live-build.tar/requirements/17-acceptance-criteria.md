# Acceptance Criteria

Этот документ превращает ключевые требования в проверяемые критерии.
Он не заменяет требования, а задает минимальную планку для реализации,
ревью и агентской проверки.

## CR-CORE Acceptance

| Requirement Group | Acceptance Criteria |
|---|---|
| `CR-CORE-001..003` | Есть работающая инсталляция CloudRING, которую можно запустить без привязки к одному публичному провайдеру; базовые функции доступны через UI/API/CLI; документация объясняет public/private/local варианты. |
| `CR-CORE-004..005` | Marketplace поддерживает сторонний сервис; ISV может пройти публикационный flow; коммерческая модель не требует блокировать экспорт данных или остановку сервиса. |
| `CR-CORE-006` | Для каждого поддержанного класса сервиса есть documented portability story: export, migration, compatible targets или явное ограничение. |
| `CR-CORE-007` | Runtime/backend можно заменить за контрактом capability без изменения пользовательского order/API flow. |
| `CR-CORE-008` | Placement flow принимает jurisdiction/data residency constraints и отказывает при невозможности выполнить policy. |
| `CR-CORE-009..010` | Пользователь видит audit, placement, provider chain и security/compliance status критичных сервисов. |
| `CR-CORE-011..012` | Один и тот же сервисный контракт применим минимум в local и private профиле; public/edge профили имеют compatibility declaration. |
| `CR-CORE-013` | В едином portal/API пользователь видит сервисы, инстансы, usage, состояние и доступные действия across presences. |
| `CR-CORE-014..015` | Новое архитектурное изменение связано с requirement/ADR; AI-агент может найти why, acceptance и related decisions. |

## CR-OCS Acceptance

| Requirement Group | Acceptance Criteria |
|---|---|
| `CR-OCS-001..004` | Существует versioned machine-readable schema для service manifest, capability и lifecycle; conformance test валидирует пример сервиса. |
| `CR-OCS-005..006` | Сервис не может быть опубликован без declared usage resources, health/readiness и observability contract или явного non-commercial/non-runtime исключения. |
| `CR-OCS-007..010` | Сервис может объявить зависимости, backend и UI; portal отображает зависимости и монтирует UI только через контролируемый contract. |
| `CR-OCS-011..016` | Manifest описывает resources, policy, compatibility и responsibility boundaries; publication flow показывает эти данные buyer/admin. |
| `CR-OCS-017..020` | Lifecycle operations имеют idempotency semantics; стандарт имеет version/deprecation policy; extensions не требуют изменения ядра. |
| `CR-OCS-021..027` | Manifest не содержит секретов, валидируется до запуска, поддерживает environment profiles и генерирует runtime artifacts. |
| `CR-OCS-028..032` | Service Connector проходит sandbox validation, объявляет implemented capabilities и передает lifecycle/usage/health/errors по стандарту. |

## CR-FED Acceptance

| Requirement Group | Acceptance Criteria |
|---|---|
| `CR-FED-001..003` | Минимум два независимых participant типа могут зарегистрироваться в federation registry с identity, role и capability declaration. |
| `CR-FED-004` | Presence может работать при временной потере связи и затем синхронизировать catalog/usage/audit events без дубликатов. |
| `CR-FED-005` | Пользовательский search/filter выбирает сервис по price, location, jurisdiction, provider, capability и trust profile. |
| `CR-FED-006..007` | Есть demonstrable cross-provider scenario: backup, replication, DR или migration с policy check и audit trail. |
| `CR-FED-008..010` | Federation governance описывает trust anchors, conformance, suspension, disputes и event audit. |
| `CR-FED-011..018` | Marketplace публикация включает certification, compatibility, commercial terms, policy-based availability и support/update terms. |
| `CR-FED-019..036` | Usage gateway принимает/отклоняет/quarantine/replay usage events с idempotency, product-scoped access, versioned API, period/overlap policy, visible backpressure, redacted diagnostics, attribution from offer/order/entitlement context, settlement trace and offline entitlement simulation. |

## CR-SELF Acceptance

| Requirement Group | Acceptance Criteria |
|---|---|
| `CR-SELF-001..006` | Пользователь может найти, заказать, наблюдать, изменить, остановить и экспортировать поддержанный сервис без ручного обращения к оператору. |
| `CR-SELF-007..012` | Администратор может установить, проверить health, обновить через plan/apply/validate и настроить базовые policy через UI/API/CLI. |
| `CR-SELF-013..016` | Провайдер может пройти onboarding, опубликовать presence capability, цены, SLA и видеть settlement/revenue/support state. |
| `CR-SELF-017..020` | ISV может создать service candidate, пройти conformance/security/billing/docs checks и получить publish readiness report. |
| `CR-SELF-021..028` | Агентские действия имеют identity, scopes, plan, dry-run for risky changes, audit, validation result и secret-safe execution. |

## CR-METRIC Acceptance

| Requirement Group | Acceptance Criteria |
|---|---|
| `CR-METRIC-001..005` | Для каждого marketplace service показывается portability score, export support, provider alternatives и proprietary dependency ratio. |
| `CR-METRIC-006..010` | Telemetry продукта измеряет time to first service, self-service completion, remediation success, admin toil и agent-runbook coverage. |
| `CR-METRIC-011..015` | Marketplace dashboard показывает publication lead time, certification pass rate, active services, revenue share и trust score. |
| `CR-METRIC-016..020` | Federation dashboard показывает participants by type, catalog freshness, settlement accuracy, cross-provider success и disconnected recovery. |
| `CR-METRIC-021..025` | Developer dashboard показывает service creation time, local debug success, task portability, docs completeness и conformance feedback time. |
| `CR-METRIC-026..030` | Security dashboard показывает secrets exposure, policy decision coverage, audit completeness, artifact verification и remediation lead time. |
| `CR-METRIC-031..050` | Evolution, operational resilience and product design quality dashboard показывает signal-to-learning time, ADR review, conformance drift, technology refresh, repeated incident reduction, agent proposal defect rate, regression coverage, source-history/evidence coverage, stateful recovery freshness, task-intent completion, consequence visibility, alternative explanation, support-ready failure, jurisdiction/economics disclosure, design regression learning and human-agent parity. |
| `CR-GOV-011..026` | Source/evolution workflow превращает repeated signals в requirements/ADR/runbooks/checks или rejected reasons, с impact analysis, versioned conformance, exception ownership, closure outcome, anonymization checks, coverage manifest and original-scope completion audit. |
| `CR-CONF-001..040` | Каждый stage имеет readiness profile с evidence, blockers, statuses, owners, scoped exceptions, agent-readable report, versioning, freshness, role scenario coverage, stop-condition cases, product design quality review, OCS information model evidence, lifecycle command surface evidence, service dependency/deployment evidence, billing runtime evidence, settlement closure evidence, stateful recovery evidence, documentation decision-memory evidence, secret runtime readiness evidence, base OS image factory evidence, UI extension runtime certification evidence, agent handoff and next actions. |
| `CR-CAPEVID-001..030` | Capability Evidence Matrix связывает detailed capability contracts со stage-aware proof, blockers, non-goals, freshness, approvals, local autonomy, federation scope, OCS/service/security evidence, runtime/task/docs/plugin redaction evidence, image/artifact sealed-readiness evidence, UI extension/runtime certification, settlement closure evidence, regression/negative validation, source/history coverage manifest, documentation decision-memory evidence, secret runtime readiness evidence, service dependency/deployment evidence and base OS image factory evidence. |
| `CR-CAP-001..008` | Capability map показывает purpose, users, stage, dependencies, anti-lock-in reason, agent-operability expectation and readiness profile for major CloudRING capability clusters. |
| `CR-WORK-001..008` | Workstream backlog связывает product outcome, stage target, requirements, ADR, conformance, dependencies, evidence and stop conditions for AI-agent execution. |
| `CR-END2END-001..032` | End-to-end architecture доказывает, что CloudRING является цельной cloud-of-clouds платформой: local ownership, role journeys, service-as-product, presences, provider chain, unified UI/API/CLI/Agent vocabulary, private/public/global marketplace, jurisdiction policy, anti-lock-in, extensions, trust, evidence-first operations, AI-agent boundaries, commercial exit, cross-provider operations, learning loop and technology refresh. |
| `CR-SRCOV-001..018` | Source coverage audit доказывает, что source intake имеет manifest, file/ref/history coverage status, explicit exclusions, source-safety gates, completion audit, non-claims and next exhaustive passes before any full-coverage claim. |
| `CR-SPECTPL-001..034` | Specification templates доказывают, что OCS manifest, OCS supporting contracts, OCS information model, conformance report, evidence bundle, profile change record, role scenario fixture, source coverage manifest, product design quality review, billing runtime evidence, settlement closure evidence, stateful recovery evidence, documentation decision-memory evidence, secret runtime readiness evidence, service dependency/deployment evidence, base OS image readiness evidence and UI extension runtime certification evidence имеют reusable product-level shape with evidence, owners, freshness, blockers, source-safety, non-goals, role coverage and agent handoff. |
| `CR-SPECEX-001..022` | Synthetic examples доказывают, что templates can be filled safely with synthetic objects for OCS manifest, supporting OCS contracts, OCS information model, conformance report, evidence bundle, profile change record, source coverage manifest, product design quality review, billing runtime evidence, settlement closure evidence, stateful recovery evidence, documentation decision-memory evidence, secret runtime readiness evidence, service dependency/deployment evidence, base OS image readiness evidence, UI extension runtime certification evidence and expanded role scenarios without old source access or implementation lock-in. |
| `CR-DESIGNQ-001..024` | Product design quality requirements доказывают, что user-impacting flows are task-based, consequence-visible, comparable, economics-aware, jurisdiction-aware, support-ready, human-agent consistent and source-safe. |
| `CR-DOMAIN-001..020` | Domain model отделяет product service, version, instance, presence, environment/runtime profiles, dependency connections, generated artifacts, task operations, plugins/UI extensions, validation rules and command results across control plane/runtime/artifact boundaries. |
| `CR-OCSCONTRACT-001..046` | Open Cloud Standard доказывает versioned service manifest, manifest field matrix, unknown-field policy, schema shape, environment/secret binding, dependency connection, lifecycle result object, usage, health, policy, responsibility, portability, UI embed descriptor, validation/error parity, connector, extensions, generated artifact provenance and conformance contract. |
| `CR-OCSIM-001..036` | OCS information model доказывает semantic model, artifact kind registry, canonical core field catalog, field registry, unknown-field policy, extension lifecycle, compatibility classes, validation catalog, effective model report, conformance suite, schema governance and source-safe model evolution. |
| `CR-LIFECMD-001..032` | Service lifecycle command surface доказывает, что create/validate/debug/start/stop/log/env/docs/task/plugin/generator actions являются product contracts with preflight, risk, approval, structured result, cleanup, source-safety, generated-artifact provenance and support-ready evidence. |
| `CR-SERVICEFACTORY-001..050` | Service Factory/Local Runtime обеспечивает templates, local dependency runtime, runtime profile/state model, preflight, route/port conflict checks, command matrix, start/stop/status/log/debug/doc/env, debug split, generated artifacts, cleanup, task runner, plugins, offline/private distribution, candidate readiness bundle and safe agent-readable contribution. |
| `CR-SECSUPPLY-001..038` | Security/Secrets/Supply Chain защищает secret boundary, brokered access ledger, classified secret fields, scoped credentials, usage/API access, redaction, artifact provenance/integrity, release evidence, image hardening, pre/post cleanup, sealed-image residue, diagnostic boundary, freshness checks, validation negative fixtures, extension isolation/trust manifest, trust anchors, operational evidence redaction, source/history hygiene and source safety. |
| `CR-FEDNET-001..030` | Federation/Global Trust Network поддерживает participant registry, scoped sync, authentic/replay-safe events, trust anchors, conformance downgrades, scoped usage/settlement sync, disputes, suspension/revocation, global discovery, provider-chain transparency, offboarding and local autonomy. |
| `CR-IAM-001..018` | IAM/Resource Manager доказывает stable resource identity, ownership, scoped permissions, agent identity, audit, quotas, local autonomy and safe deletion/suspension. |
| `CR-POLICY-001..020` | Policy/Placement принимает explainable decisions до provisioning/data movement и учитывает jurisdiction, provider chain, trust, budget, capacity, portability, approvals and exceptions. |
| `CR-CATALOG-001..028` | Service Catalog/Product Control Plane управляет service/version/offer/order/instance/support boundaries, service cards, certification, provider/publisher readiness, artifact inventory/provenance/hardening, immutable identity, registration result, lifecycle plans, portability, docs, offline simulation, support-chain state and plugin trust. |
| `CR-BILL-001..036` | Billing/Entitlements/Settlement связывает usage, orders, entitlements, invoices, credits/refunds, disputes and staged participant settlement with usage gateway decision ledger, validation, idempotency, period/overlap policy, metadata limits, backpressure, replay/duplicate tests, credential-safe auth failure evidence, scoped views, diagnostics and exit support. |
| `CR-BILLRUN-001..032` | Billing runtime evidence доказывает, что billable usage intake distinguishes transport success from financial truth, returns support-safe receipts, exposes async status, separates request idempotency from event identity, handles backpressure, shutdown, replay, quarantine, release/history evidence and settlement freeze without leaking sensitive context. |
| `CR-SETTLE-001..032` | Settlement closure evidence доказывает, что provider-local and cross-participant financial closeout uses scoped closure runs, input manifests, reconciliation, freeze gates, correction lineage, dispute hold/release, participant views, approval, export, retention, release/history evidence and source-safe non-claims before money is called settled. |
| `CR-STATEFULRUN-001..032` | Stateful recovery readiness доказывает, что backup, restore, PITR, failover, topology, endpoint ownership, audit findings, access roles, source/history evidence and source-safe recovery bundles are explicit before CloudRING claims recoverability. |
| `CR-DOCMEM-001..032` | Documentation decision memory доказывает, что docs, ADR/no-ADR rationale, feedback, source-pass lessons, templates, examples, scenarios, conformance gates, owners, freshness and non-claims form a reusable source-safe product memory chain. |
| `CR-SECRETRUN-001..032` | Secret runtime readiness доказывает, что encrypted secret declarations, scope binding, key custody, public certificate freshness, reconciliation status, install/delete behavior, RBAC, health/metrics, rotation/degraded behavior, source-safety and non-claims are explicit before CloudRING claims credential runtime readiness. |
| `CR-SVCDEPLOY-001..032` | Service dependency/deployment model evidence доказывает, что service identity, profile resolution, dependency graph, component ownership, connection outputs, generated artifacts, secret-adjacent env, local-only fixtures, conflicts, portability, source-safety and non-claims are explicit before CloudRING claims dependency or generated deployment readiness. |
| `CR-BASEIMG-001..032` | Base OS image factory readiness доказывает, что governed image line, build input classification, unattended install, provisioning composition, guest readiness, cleanup/sealing, immutable artifact identity, first-boot smoke, profile-aware promotion, source-safety and non-claims are explicit before CloudRING claims reusable image readiness. |
| `CR-UICERT-001..032` | UI extension runtime certification доказывает, что embedded UI host authority, scoped context, lifecycle cleanup, validation phase semantics, stable error identity, browser/runtime evidence, accessibility, localization, artifact provenance, support owner, telemetry redaction, source-safety and non-claims are explicit before CloudRING claims private/provider UI publication readiness. |
| `CR-INFPROFILE-001..031` | Infrastructure Capability Profiles описывают replaceable compute/network/storage/backup/observability/image profiles, private/edge/public presence, versioned states, capacity, maintenance, cross-cloud connectivity, local autonomy, backend deprecation, stateful topology/endpoint ownership, artifact freshness and exit evidence. |
| `CR-OBSOPS-001..036` | Observability/Support/Operations доказывает health, telemetry correlation, unified operational state, incidents, SLO/SLA, support ownership, maintenance, remediation, emergency flow, recovery freshness, stateful audit bundle, normalized operational report, credits evidence and learning loop. |
| `CR-PORTX-001..033` | Portability/Exit/Cross-Provider Operations делает export/import/restore/migration/DR/provider exit/jurisdiction exit/offboarding проверяемыми через preflight, policy, compatibility, approval, residual-data closure, validation and evidence. |
| `CR-AGOPS-001..030` | Self-Service/Agent Operations обеспечивает consequence-before-action, shared UI/API/CLI/Agent API vocabulary, actor flows, agent identity, risk classes, scoped approvals, stage guardrails, manual-review bundle, dry-run, validation and final evidence. |
| `CR-MKT-001..040` | Marketplace journeys покрывают buyer/seller/install/update/remove/review/trust/refund/support flows, artifact/image publication, release/provenance/hardening/first-bootstrap validation, registration result, support-chain state, portability disclosure and anti-lock-in filters. |
| `CR-OPS-001..046` | Operations requirements покрывают observability, canonical UTC time, agent-safe operations, queues/backpressure, stateful services, database practice separation, topology/failover/RPO/RTO, backup/restore/PITR evidence, blocking audit, role lifecycle, source-safe operational artifacts, ADR/change history, negative scenarios and runbook/docs freshness after operational churn. |
| `CR-STAGE7-001..039` | Stage 7 доказывает continuous evolution loop, source/history intake, repeated-fix learning triggers, conformance drift, technology refresh, safe agent remediation, coverage manifest and human-owned trade-off governance. |

## CR-STAGE Acceptance

| Requirement Group | Acceptance Criteria |
|---|---|
| `CR-STAGE0-001..021` | Stage 0 доказывает, что requirements memory является source-safe, traceable, agent-readable, versioned and extensible product foundation with conformance profile and coverage discipline. |
| `CR-STAGE1-001..025` | Stage 1 доказывает законченный local service product: template, manifest, local runtime, dependency contract, docs, observability, tasks, agent-safe contribution and `stage1-service-ready` report without public-provider dependency. |
| `CR-STAGE2-001..026` | Stage 2 доказывает autonomous private presence: install, local control plane, UI/API/CLI/Agent API, IAM/resource ownership, infrastructure capability matrix, base OS image readiness, stateful restore/failover/audit proof, update path, secret-safe evidence and future federation metadata without marketplace commerce dependency. |
| `CR-STAGE3-001..026` | Stage 3 доказывает private service store: service discovery, compatibility, certification, UI extension runtime certification, install/update/remove, entitlement/licensing, trust disclosure, agent-safe store verification and no mandatory public marketplace or cross-participant settlement. |
| `CR-STAGE4-001..026` | Stage 4 доказывает public provider kit: onboarding, public offers, tenant order, scoped usage gateway, provider-local billing, security/isolation, SLA/support, operations readiness and federation-ready metadata without requiring multi-provider settlement. |
| `CR-STAGE5-001..026` | Stage 5 доказывает limited federation network: at least two independent presences, scoped sync, catalog/trust/usage/settlement evidence, cross-provider operation, dispute/suspension and `stage5-federation-ready` report without global marketplace scale. |
| `CR-STAGE6-001..032` | Stage 6 доказывает global CloudRING network: global discovery/index, local ownership preservation, policy overlays, trust fabric, global settlement, provider/jurisdiction/technology exit, appealable governance and no single global control plane. |

## Acceptance Rules For Future Requirements

1. Если требование влияет на пользователя, acceptance должен включать observable user outcome.
2. Если требование влияет на безопасность, acceptance должен включать audit/policy evidence.
3. Если требование влияет на federation, acceptance должен включать минимум two-participant scenario.
4. Если требование влияет на AI-агентов, acceptance должен включать plan, permission, validation и rollback/compensation.
5. Если требование снижает lock-in, acceptance должен включать export, migration, alternative provider или явное ограничение.
