# Legacy Source Traceability Map

Этот документ показывает, как выводы команды агентов по legacy-источникам
перенесены в требования CloudRING.

Он нужен для проверки покрытия.
Это не копия исходников и не список реализационных задач.
Конкретные технологии в этом файле являются source signals/examples, а не
обязательными будущими реализациями CloudRING.

## PDF-Derived Signals

| Signal | Куда Перенесено |
|---|---|
| Распределенная open/post-cloud платформа | `CR-CORE-001`, `CR-ARCH-021..024`, `CR-FED-001..010` |
| Разделение бизнеса и технологии | `CR-CORE-002`, `CR-ARCH-009`, `CR-CORE-011` |
| Open Cloud Standard | `CR-OCS-001..020`, `CR-ARCH-009..012` |
| Service Connector | `CR-OCS-028..032` |
| Unified portal/API | `CR-CORE-013`, `CR-ARCH-001..004` |
| Marketplace/service store | `CR-FED-011..018`, `CR-ARCH-013..016` |
| Federation and cross-provider scenarios | `CR-FED-001..010`, `CR-INFRA-026..029` |
| Private/edge/disconnected | `CR-INFRA-001..016`, `CR-ARCH-023` |
| Vendor/jurisdiction/trust lock risks | `CR-CORE-006..009`, `CR-SEC-019..024` |
| Revenue sharing and licensing | `CR-FED-028..030` |
| Cloud-of-clouds end-to-end architecture | `CR-END2END-001..032`, `CR-ARCH-001..032`, `CR-CAP-001..008` |
| Source coverage and completion audit discipline | `CR-SRCOV-001..018`, `CR-GOV-023..026`, `CR-CAPEVID-024`, `WS-020` |

## Legacy Platform Architecture Signals

| Extracted Requirement | Куда Перенесено |
|---|---|
| Paved road для микросервисов | `CR-DX-001..014`, `CR-PLAT-011..022` |
| Единый service manifest | `CR-OCS-021..027`, `CR-OCSCONTRACT-001..038` |
| DNS/runtime-safe имена | `CR-DX-012`, `CR-PLAT-021` |
| Env global + per environment overrides | `CR-OCS-023`, `CR-PLAT-019`, `CR-OCSCONTRACT-032` |
| Service components and platform components | `CR-PLAT-023..028`, `CR-ARCH-013..020`, `CR-OCSCONTRACT-033` |
| Generated local artifacts | `CR-PLAT-016..018`, `CR-DX-007`, `CR-OCSCONTRACT-019`, `CR-OCSCONTRACT-037`, `CR-SERVICEFACTORY-009`, `CR-SERVICEFACTORY-034` |
| Platform-owned build recipe | `CR-DX-010..011`, `CR-SEC-013..018` |
| UTC/default operational baseline | `CR-OPS-036`, `CR-SEC-013..018` |
| CLI bootstrap/start/service/task/lib/plugin | `CR-DX-001..007`, `CR-SELF-007..012`, `CR-SERVICEFACTORY-001..050`, `CONF-STAGE1-011`, `CONF-STAGE1-014`, `CONF-STAGE1-016..019` |
| Platform lifecycle command surface | `SRC-PASS-011`, `CR-LIFECMD-001..032`, `CR-CONF-032`, `WS-024`; current-tree source-slice lessons for manifest-first command surfaces, create/scaffold, validation, debug/start split, environment export, docs preview, task/plugin boundaries, generated artifact provenance, preflight, cleanup and support-ready evidence without source-history claim. |
| Service dependency/deployment model | `SRC-PASS-016`, `CR-SVCDEPLOY-001..032`, `CR-CONF-037`, `CR-CAPEVID-027`, `CR-SPECTPL-031`, `CR-SPECEX-019`, `WS-029`; source-safe lessons for effective service model, dependency graph, component ownership, profile overrides, generated artifact inventory, env handoff, conflict preflight, task/data roles, dependency portability and non-claims without raw generated files, local fixture values or runtime/history claim. |
| Base OS image factory readiness | `SRC-PASS-017`, `CR-BASEIMG-001..032`, `CR-CONF-038`, `CR-CAPEVID-028`, `CR-SPECTPL-032`, `CR-SPECEX-020`, `WS-030`; source-safe lessons for base image identity, build input classification, unattended install, provisioning roles, guest readiness, cleanup/sealing, immutable artifact identity, first-boot evidence gap, promotion lifecycle and non-claims without raw build profiles, private values, live build/boot or full history claim. |
| UI extension runtime certification | `SRC-PASS-018`, `CR-UICERT-001..032`, `CR-CONF-039`, `CR-CAPEVID-029`, `CR-SPECTPL-033`, `CR-SPECEX-021`, `WS-031`; source-safe lessons for host authority, typed embed descriptor, scoped context, lifecycle cleanup, validation phase semantics, stable error identity, browser/runtime gap, accessibility/localization gap, artifact publication evidence and non-claims without raw frontend source, private runtime values, live browser execution or marketplace publication claim. |
| Local provider close to production | `CR-DX-004..006`, `CR-INFRA-003..006`, `CR-SERVICEFACTORY-029..032` |
| Debug dependencies separately from service | `CR-PLAT-013`, `CR-DX-002`, `CR-SERVICEFACTORY-032` |
| Containerized portable tasks | `CR-PLAT-029..034`, `CR-OCSCONTRACT-024`, `CR-OCSCONTRACT-035`, `CR-SERVICEFACTORY-012..014`, `CR-SERVICEFACTORY-033` |
| Service template with docs/metrics/traces/logs | `CR-DX-008..014`, `CR-OPS-001..008`, `CR-SERVICEFACTORY-001..018`, `CR-SERVICEFACTORY-035` |
| Observability best practices | `CR-OPS-001..008` |
| Stateful data service operational practice | `CR-OPS-021..028`, `CR-OPS-037..046`, `CR-OBSOPS-031..036`, `CR-INFPROFILE-031`, `CR-SECSUPPLY-038`, `CR-STATEFULRUN-001..032`, `SRC-PASS-005`, `SRC-PASS-013` |
| Docs as lifecycle | `CR-DX-015..019`, `CR-PLAT-022`, `CR-SERVICEFACTORY-015..016`, `CR-SERVICEFACTORY-035`, `CR-DOCMEM-001..014` |
| Documentation and decision memory | `SRC-PASS-014`, `CR-DOCMEM-001..032`, `CR-CONF-035`, `CR-CAPEVID-025`, `CR-SPECTPL-029`, `CR-SPECEX-017`, `WS-027`; source-safe lessons for docs-as-product-control-plane, audience/task navigation, onboarding/reference/lifecycle docs, manifest/task/command documentation, boilerplate service docs, showcase examples, ADR/no-ADR rationale, feedback triage, freshness, source-safety and rehydration without old source access. |
| Secret runtime readiness | `SRC-PASS-015`, `CR-SECRETRUN-001..032`, `CR-CONF-036`, `CR-CAPEVID-026`, `CR-SPECTPL-030`, `CR-SPECEX-018`, `WS-028`; source-safe lessons for encrypted declaration vs normal config, scope binding, key custody/public certificate boundary, observed generation/conditions, install/delete retention, RBAC, health/metrics, rotation/degraded behavior and non-claims without raw values, encrypted payloads or history claim. |
| ADR | `CR-OPS-029..032`, `CR-AGENT-003`, `CR-DOCMEM-015..021`, `CR-DOCMEM-030..032` |
| Binary plugins | `CR-DX-020..024`, `CR-SERVICEFACTORY-021..023`, `CR-SERVICEFACTORY-036..037`, `CR-SECSUPPLY-015..016` |
| Asset registry/bootstrap updates | `CR-SELF-007..012`, `CR-INFRA-001..006`, `CR-SERVICEFACTORY-038..039` |
| UI validation/bootstrap | `CR-DX-025..029`, `CR-OCSCONTRACT-017..018`, `CR-OCSCONTRACT-036`, `CR-OCSCONTRACT-038`, `CR-OCSCONTRACT-045..046`, `CR-SECSUPPLY-016..017`, `CR-SECSUPPLY-032`, `CR-SECSUPPLY-034..036`, `CR-UX-021`, `CR-UICERT-001..032`, `CONF-STAGE1-010`, `CONF-STAGE1-014`, `CONF-STAGE3-008`, `CONF-STAGE3-010`, `CONF-STAGE3-012`, `SRC-PASS-004`, `SRC-PASS-018` |
| Сквозная связка service contract, local runtime, provider/store, federation, billing, trust and agent operations | `CR-END2END-001..032`, `WS-019` |
| Provider/publisher readiness package | `CR-CATALOG-021..028`, `CR-MKT-029..040`, `CR-SECSUPPLY-035..037` |

## Git-History Signals

| Extracted Requirement | Куда Перенесено |
|---|---|
| Unified usage metrics gateway | `CR-FED-019..036`, `CR-BILL-001..036`, `CR-BILLRUN-001..032`, `CR-SECSUPPLY-007`, `CR-CAPEVID-021` |
| Billing runtime evidence and settlement trust | `SRC-PASS-012`, `CR-BILLRUN-001..032`, `CR-CONF-033`, `CR-SPECTPL-027`, `CR-SPECEX-015`, `WS-025`; source-safe lessons for billable usage receipt/status, event identity, idempotency conflict, access freshness, backpressure, replay/quarantine, generated docs/config gates, release/history evidence and settlement freeze without downstream settlement claim. |
| Stateful restore and failover readiness | `SRC-PASS-013`, `CR-STATEFULRUN-001..032`, `CR-CONF-034`, `CR-SPECTPL-028`, `CR-SPECEX-016`, `WS-026`; source-safe lessons for reusable recovery evidence, topology, backup/archive, restore/PITR, failover, endpoint ownership, audit findings, access roles, branch/history coverage and provider recovery support without live restore/failover claim. |
| Product-scoped access tokens | `CR-FED-023..025`, `CR-SEC-004..006`, `CR-SECSUPPLY-005..007`, `CR-BILL-029..030` |
| Metric schema: external id, resource, usage, period, meta | `CR-FED-019..022` |
| UTC periods and idempotency | `CR-FED-021..022`, `CR-OPS-017..018` |
| Backpressure and queue overflow | `CR-OPS-015..020`, `CR-OPS-033..034`, `CR-BILL-028`, `CR-BILL-034..035` |
| Prometheus/logs/traces/health | `CR-OPS-001..008` |
| Versioned API and docs | `CR-OCS-012..013`, `CR-FED-022` |
| Encrypted configuration and secret manager instead of plaintext | `CR-SEC-007..012`, `CR-SECSUPPLY-001..004`, `CR-SECSUPPLY-027..029`, `CR-SECRETRUN-001..032` |
| Reproducible marketplace images with publication handoff | `CR-INFRA-017..025`, `CR-SEC-013..018`, `CR-SECSUPPLY-009..014`, `CR-SECSUPPLY-030..037`, `CR-MKT-029..036`, `CR-CATALOG-021..026`, `CR-BASEIMG-019..027`, `SRC-PASS-017` |
| VM image bootstrap, growpart, guest tools, serial console, crash dump and sealed-image residue | `CR-INFRA-019..024`, `CR-SECSUPPLY-011..012`, `CR-SECSUPPLY-031`, `CR-INFPROFILE-008`, `CR-BASEIMG-006..018`, `CR-BASEIMG-021..024`, `SRC-PASS-017` |
| Critical database/DNS HA | `CR-OPS-021..028`, `CR-OPS-038..046`, `CR-OBSOPS-031..036`, `CR-INFPROFILE-031`, `CR-STATEFULRUN-004..006`, `CR-STATEFULRUN-024..028`, `SRC-PASS-005`, `SRC-PASS-013` |
| Infra audit runs and stateful evidence bundles | `CR-OPS-009..014`, `CR-OPS-025`, `CR-OPS-043`, `CR-OBSOPS-031`, `CR-OBSOPS-034..036`, `SRC-PASS-005` |
| Micro-frontend contract | `CR-DX-025..026`, `CR-OCSCONTRACT-017`, `CR-OCSCONTRACT-036`, `CR-SECSUPPLY-016`, `CR-SECSUPPLY-032`, `CR-CAPEVID-020`, `CR-UICERT-001..013`, `CR-UICERT-021..032`, `SRC-PASS-004`, `SRC-PASS-018` |
| Frontend validation library | `CR-DX-027..029`, `CR-OCSCONTRACT-018`, `CR-OCSCONTRACT-038`, `CR-OCSCONTRACT-045..046`, `CR-SECSUPPLY-017`, `CR-SECSUPPLY-034..036`, `CR-CAPEVID-017`, `CR-UICERT-014..021`, `CR-UICERT-030..032`, `SRC-PASS-004`, `SRC-PASS-018` |
| Git history containing secret-class/security signals | `CR-SECSUPPLY-022`, `CR-SECSUPPLY-033`, `CR-CAPEVID-015`, `CR-CAPEVID-022` |
| Old platform superseded by next-generation approach | `CR-SERVICEFACTORY-027`, `CR-OCSCONTRACT-026`, `CR-CAPEVID-012` |
| Version-pinned common libs/template libraries | `CR-SEC-018`, `CR-PLAT-029..034` |
| Release/tag discipline and repeated fix history | `CR-SECSUPPLY-035`, `CR-STAGE7-038..039`, `CR-METRIC-037..039`, `CR-CAPEVID-023..024`, `SRC-PASS-004` |
| Operational docs/runbook churn | `CR-OPS-035`, `CR-STAGE7-005`, `CR-STAGE7-038` |
| Stateful backup/restore and audit history | `CR-OPS-041..043`, `CR-OBSOPS-029`, `CR-OBSOPS-031..035`, `CR-INFPROFILE-005..006`, `CR-STATEFULRUN-001..032`, `CONF-STAGE2-005`, `CONF-STAGE2-012`, `CONF-STAGE4-007`, `CONF-STAGE4-014`, `SRC-PASS-005`, `SRC-PASS-013` |
| Historical topology/log/IaC/grant source-safety classes | `CR-SECSUPPLY-022`, `CR-SECSUPPLY-033`, `CR-SECSUPPLY-038`, `CR-CAPEVID-015`, `CR-CAPEVID-024`, `CONF-STAGE2-007`, `CONF-STAGE4-005`, `SRC-PASS-005` |
| Coverage limitations from targeted and history-focused analysis | `CR-SRCOV-001..018`, `CR-STAGE7-039`, `CR-GOV-023..026` |
| Requirements-memory consistency pass | `SRC-PASS-006`; non-legacy-source consistency review for architecture vocabulary, ADR candidates, conformance drift, traceability freshness, source-safety scope and validation discipline. |
| Significant source inventory classification closure | `SRC-PASS-007`, `CR-SRCOV-001..018`, `CR-SPECTPL-001..026`, `CR-CONF-028..031`, `CR-STAGE7-039`; proves all 418 significant files are classified by source class after common-noise exclusions, but does not claim line-by-line or full-history audit. |
| Agent-readable templates and starter scenario fixtures | `CR-SPECTPL-001..033`, `CR-CONF-028..039`, `WS-021`, `WS-027`, `WS-028`, `WS-029`, `WS-030`, `WS-031`, `SRC-PASS-007`, `SRC-PASS-012`, `SRC-PASS-014`, `SRC-PASS-015`, `SRC-PASS-016`, `SRC-PASS-017`, `SRC-PASS-018`; OCS manifest, OCS information model, supporting OCS contracts, conformance report, evidence bundle, profile change record, role scenario fixture, source coverage manifest, product design quality review, billing runtime evidence, stateful recovery evidence, documentation decision-memory templates, secret runtime readiness templates, service dependency/deployment templates, base OS image readiness templates and UI extension runtime certification templates. |
| Filled synthetic examples and expanded role fixtures | `CR-SPECEX-001..021`, `CR-SPECTPL-001..033`, `CR-CONF-028..039`, `SRC-PASS-008`, `SRC-PASS-012`, `SRC-PASS-014`, `SRC-PASS-015`, `SRC-PASS-016`, `SRC-PASS-017`, `SRC-PASS-018`; safe examples for OCS, OCS information model, conformance, evidence, profile change, source coverage, product design quality, billing runtime evidence, stateful recovery evidence, documentation decision-memory evidence, secret runtime readiness evidence, service dependency/deployment evidence, base OS image readiness evidence, UI extension runtime certification evidence and role scenarios without source-copy or implementation lock-in. |
| Product design quality and scenario depth | `SRC-PASS-009`, `CR-DESIGNQ-001..024`, `CR-METRIC-044..050`, `CR-CONF-030`, `CR-SPECTPL-025`, `WS-022`; task-based quality evidence for visible consequences, alternatives, provider economics, jurisdiction overlays, safe negative paths and human-agent parity. |
| OCS information model and schema governance | `SRC-PASS-010`, `CR-OCSIM-001..036`, `CR-CONF-031`, `CR-SPECTPL-026`, `CR-SPECEX-014`, `WS-023`; semantic standard model, artifact kind registry, canonical core fields, field registry, extension lifecycle, compatibility classes, versioned conformance suite and schema governance record. |
| Platform lifecycle command surface current-tree pass | `SRC-PASS-011`, `CR-LIFECMD-001..032`, `CR-CONF-032`, `WS-024`; bounded source-safe extraction of command/action product contracts, generated artifact boundaries, task/plugin trust model and lifecycle evidence without source-history or runtime-execution claim. |
| Stateful restore/failover readiness pass | `SRC-PASS-013`, `CR-STATEFULRUN-001..032`, `CR-CONF-034`, `CR-SPECTPL-028`, `CR-SPECEX-016`, `WS-026`; bounded current-tree plus history/theme extraction for reusable recovery evidence template, synthetic example, Stage 2 restore/failover scenarios and Stage 4 provider recovery scenario without source-copy or live infrastructure claim. |
| Documentation decision-memory pass | `SRC-PASS-014`, `CR-DOCMEM-001..032`, `CR-CONF-035`, `CR-CAPEVID-025`, `CR-SPECTPL-029`, `CR-SPECEX-017`, `WS-027`; bounded source-safe extraction of documentation, ADR, feedback and developer-guidance product-memory requirements without raw docs copying, runtime verification or full history claim. |
| Secret runtime readiness pass | `SRC-PASS-015`, `CR-SECRETRUN-001..032`, `CR-CONF-036`, `CR-CAPEVID-026`, `CR-SPECTPL-030`, `CR-SPECEX-018`, `WS-028`; bounded current-tree source-safe extraction for encrypted declaration boundaries, scope binding, key custody, public certificate freshness, observed generation/conditions, install/delete retention, RBAC, health/metrics and rotation/degraded behavior without raw values, live runtime, vulnerability, dependency or history claim. |
| Service dependency/deployment model pass | `SRC-PASS-016`, `CR-SVCDEPLOY-001..032`, `CR-CONF-037`, `CR-CAPEVID-027`, `CR-SPECTPL-031`, `CR-SPECEX-019`, `WS-029`; bounded current-tree source-safe extraction for service identity, profile resolution, dependency graph, generated artifacts, env handoff, component ownership, conflict preflight and portability without raw generated files, runtime execution, vulnerability, dependency-license, secret-value or history claim. |
| Base OS image factory readiness pass | `SRC-PASS-017`, `CR-BASEIMG-001..032`, `CR-CONF-038`, `CR-CAPEVID-028`, `CR-SPECTPL-032`, `CR-SPECEX-020`, `WS-030`; bounded current-tree plus local history-shape source-safe extraction for base image identity, input classification, unattended install, provisioning roles, guest readiness, cleanup/sealing, artifact identity and promotion lifecycle without raw build profiles, live build/boot, vulnerability, compliance, deleted-path or full history claim. |
| UI extension runtime certification pass | `SRC-PASS-018`, `CR-UICERT-001..032`, `CR-CONF-039`, `CR-CAPEVID-029`, `CR-SPECTPL-033`, `CR-SPECEX-021`, `WS-031`; bounded current-tree plus local history-shape source-safe extraction for validation phase semantics, field error lifecycle, dependent rules, stable error identity gap, browser/runtime gap, accessibility/localization gap, host authority, scoped context, lifecycle cleanup and publication evidence without raw frontend source, live browser execution, marketplace certification, vulnerability, compliance or full history claim. |

## Third-Party / Reference Signals

| Source Type | Как Использовано |
|---|---|
| Encrypted secret controller snapshot | Требования к GitOps-friendly encrypted secrets: `CR-SEC-008..011`, `CR-SECSUPPLY-001..004`, `CR-SECSUPPLY-027..029`, `CR-SECRETRUN-001..032` |
| Vendored dependencies | Не переносились как требования; использованы только как compatibility context. |
| Empty/sandbox repo | Требований не извлечено. |

## Открытые Вопросы Из Агентов

| Вопрос | Где Зафиксирован |
|---|---|
| Kubernetes-only или несколько runtime backend? | `CR-ARCH-017..020`, `CR-DX-004`, требует ADR. |
| Production-grade generators вместо legacy stubs | `CR-PLAT-016`, требует будущего ADR. |
| Port conflicts for local multi-component compose | `CR-PLAT-021`, `CR-DX-005`, требует design. |
| Secrets model: local, CI, Vault, cloud secret manager | `CR-SEC-007..012`, требует threat model. |
| CLI/task/boilerplate update versioning | `CR-SELF-009`, `CR-INFRA-001..006`, требует release model. |
| Plugin security model | `CR-DX-020..024`, `CR-SEC-025..027`, `ADR-0006`. |
| Minimal component catalog | `CR-PLAT-001..010`, требует MVP selection. |
| Portal over CLI | `CR-ARCH-001..004`, `CR-SELF-001..006`, требует product design. |
