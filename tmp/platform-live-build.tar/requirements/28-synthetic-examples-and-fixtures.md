# Synthetic Examples And Fixtures

Этот документ задает требования к заполненным synthetic examples for
CloudRING. Templates из `27-agent-readable-specification-templates.md`
описывают форму. Synthetic examples показывают, как эта форма заполняется
без доступа к старым исходникам, private context or implementation-specific
schema choice.

Examples are product evidence examples, not final implementation schemas.

## Requirements

| ID | Требование | Почему | Acceptance |
|---|---|---|---|
| CR-SPECEX-001 | CloudRING must keep source-safe filled examples for recurring specification templates. | Пустой template не учит агента отличать good evidence from vague prose. | `examples/` contains filled OCS, conformance, evidence, profile-change and source-coverage examples. |
| CR-SPECEX-002 | Filled examples must use only synthetic objects. | Examples should be reusable and safe to share. | Examples reference objects from `scenarios/synthetic-fixture-catalog.md` or explicitly generic IDs. |
| CR-SPECEX-003 | Filled OCS manifest example must show service-as-product without choosing final schema format. | Future implementation needs concrete meaning, not a frozen serialization. | Example covers service identity, profiles, dependencies, lifecycle, usage, observability, policy, portability, UI/docs, generated artifacts and source-safety. |
| CR-SPECEX-004 | Supporting OCS example must show field matrix, precedence, validation code catalog and artifact provenance. | Reimplementing OCS requires more than one manifest block. | Example links fields, defaults, unknown-field policy, profile overrides, validation codes and generated artifact freshness. |
| CR-SPECEX-005 | Conformance report example must show hard gates, warnings, future-stage gaps and role coverage. | Readiness must be reproducible from a filled report. | Example includes profile version, checks, criticality, blocker class, evidence bundle IDs, role coverage, agent handoff and validation summary. |
| CR-SPECEX-006 | Evidence bundle example must state what it proves and what it does not prove. | Evidence without non-claims creates false confidence. | Example includes `proves`, `does_not_prove`, freshness, owner, validation, source-safety and handoff consequence. |
| CR-SPECEX-007 | Profile change example must show compatibility and rollout impact. | Conformance evolution must not surprise participants. | Example includes changed checks, reason, affected profiles, compatibility impact, rollout note, owner and source-safety. |
| CR-SPECEX-008 | Source coverage example must distinguish classification closure from full audit. | Source learning must be honest about limits. | Example includes raw/significant/excluded counts, source classes, coverage mode, non-claims and validation summary. |
| CR-SPECEX-009 | Filled scenario examples must reduce role-coverage gaps without pretending completion. | A scenario corpus should grow honestly. | Role coverage matrix marks starter fixtures, future-expand and not-applicable explicitly. |
| CR-SPECEX-010 | Filled examples must include negative/blocked cases where relevant. | Product readiness includes safe refusal. | Examples cover policy denied, stale evidence/trust, missing owner/support, duplicate billing risk, unsupported portability or unsafe evidence where relevant. |
| CR-SPECEX-011 | Examples must link to requirements, ADRs, profiles and workstreams. | Agents need graph context to continue work. | Each example has requirement refs and profile/workstream refs where applicable. |
| CR-SPECEX-012 | Examples must not contain real provider, customer, source, endpoint, network, person or secret material. | Examples are intended to be publishable product memory. | Private marker and strict secret scans pass outside the review checklist. |
| CR-SPECEX-013 | Filled product design quality review example must show task-based review, consequence visibility, alternatives, jurisdiction, economics and human-agent parity. | Future agents need to see how design quality evidence is filled without real source context. | Example covers role intent, recommended and alternative offers, visible consequences, provider economics, jurisdiction overlay, failure states, metrics, decision and source safety. |
| CR-SPECEX-014 | Filled OCS information model example must show model version, artifact kind, field registry, extension lifecycle, conformance suite and change governance. | Future agents need a source-safe example of the standard's decision system. | Example covers service manifest baseline, core fields, unknown field policy, extension registry, validation codes, conformance suite and model governance. |
| CR-SPECEX-015 | Filled billing runtime evidence example must show source-safe money-flow readiness without real tenant or provider data. | Future agents need a concrete example of usage receipt/status, replay and settlement-freeze evidence without copying source context. | Example covers synthetic events, receipt/status, duplicate/conflict handling, batch outcome, backpressure, drain, quarantine/replay, access freshness, release evidence, settlement freeze and non-claims. |
| CR-SPECEX-016 | Filled stateful readiness example must show source-safe recovery proof without real topology, logs or provider data. | Future agents need a concrete example of backup, restore, PITR, failover and audit evidence without copying operational context. | Example covers synthetic topology, backup/archive, restore target, PITR, failover drill, audit findings, role matrix, source/history evidence, source safety and non-claims. |
| CR-SPECEX-017 | Filled documentation decision-memory example must show source-safe product memory without old docs or private context. | Future agents need to see how documentation, ADR/no-ADR rationale, scenario, conformance, source pass, owner, freshness and non-claims connect. | Example covers synthetic docs package, decision-memory links, feedback outcome, source-safety, warnings, unresolved gaps and agent handoff. |
| CR-SPECEX-018 | Filled secret runtime readiness example must show source-safe credential runtime proof without real secret values, endpoints or key material. | Future agents need to see how encrypted declarations, scope, key custody, reconciliation, install/delete, RBAC, health/metrics, rotation and non-claims connect. | Example covers synthetic secret classes, scope binding, public certificate evidence, observed generation/conditions, install/delete behavior, access roles, degraded mode, source safety and non-claims. |
| CR-SPECEX-019 | Filled service dependency/deployment evidence example must show source-safe local dependency proof without real generated env, endpoints or credentials. | Future agents need to see how profile resolution, dependency graph, generated artifacts, preflight, portability and non-claims connect. | Example covers synthetic service model, dependency classes, component ownership, redacted outputs, generated artifact inventory, local-only warnings, portability gaps, source safety and non-claims. |
| CR-SPECEX-020 | Filled base OS image readiness example must show source-safe image factory proof without raw build profiles, endpoints, credentials or copied config. | Future agents need to see how install, provisioning, guest readiness, cleanup, artifact identity, first-boot and promotion non-claims connect. | Example covers synthetic image line, input classes, install/provisioning, guest tooling, cleanup/sealing, artifact lifecycle, CI limits, source safety and non-claims. |
| CR-SPECEX-021 | Filled UI extension runtime certification example must show source-safe embedded UI and validation proof without raw source, tenant data or private runtime values. | Future agents need to see how host authority, lifecycle, validation parity, accessibility, artifact identity, support owner and non-claims connect. | Example covers synthetic UI extension, embed contract, runtime lifecycle, validation runtime, publication trust, source safety and non-claims. |
| CR-SPECEX-022 | Filled settlement closure example must show source-safe financial closeout proof without real invoices, providers, tenants, endpoints or payment data. | Future agents need to see how closure run, reconciliation, dispute hold/release, participant shares, approval, export and non-claims connect. | Example covers synthetic closure run, input manifest, reconciliation warning, disputed amount hold, scoped party views, approval gaps, source safety and blocked settlement non-claim. |

## Example Index

- [examples/ocs-service-manifest-example.md](examples/ocs-service-manifest-example.md)
- [examples/ocs-supporting-contracts-example.md](examples/ocs-supporting-contracts-example.md)
- [examples/conformance-report-example.md](examples/conformance-report-example.md)
- [examples/evidence-bundle-examples.md](examples/evidence-bundle-examples.md)
- [examples/profile-change-record-example.md](examples/profile-change-record-example.md)
- [examples/source-coverage-manifest-example.md](examples/source-coverage-manifest-example.md)
- [examples/product-design-quality-review-example.md](examples/product-design-quality-review-example.md)
- [examples/ocs-information-model-example.md](examples/ocs-information-model-example.md)
- [examples/billing-runtime-evidence-example.md](examples/billing-runtime-evidence-example.md)
- [examples/stateful-readiness-evidence-example.md](examples/stateful-readiness-evidence-example.md)
- [examples/documentation-decision-memory-example.md](examples/documentation-decision-memory-example.md)
- [examples/secret-runtime-readiness-evidence-example.md](examples/secret-runtime-readiness-evidence-example.md)
- [examples/service-dependency-deployment-evidence-example.md](examples/service-dependency-deployment-evidence-example.md)
- [examples/base-os-image-readiness-evidence-example.md](examples/base-os-image-readiness-evidence-example.md)
- [examples/ui-extension-runtime-certification-example.md](examples/ui-extension-runtime-certification-example.md)
- [examples/settlement-closure-evidence-example.md](examples/settlement-closure-evidence-example.md)

## Non-Goals

Synthetic examples are not:

- final schema format;
- generated code;
- runtime test fixtures;
- legal/commercial documents;
- source inventory with raw paths;
- proof that full source/history analysis is complete.
